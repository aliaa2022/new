/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;
void printArray( const int [][ 3 ] ); // prototype
const int rows = 2; // global variable
const int columns = 3; // global variable
int main()
{
int array1[ rows ][ columns ] = { { 1, 2, 3 }, { 4, 5, 6 } };
int array2[ rows ][ columns ] = { 1, 2, 3, 4, 5 };
int array3[ rows ][ columns ] = { { 1, 2 }, { 4 } };
cout << "Values in array1 by row are:" << endl;
printArray( array1 );
cout << "\nValues in array2 by row are:" << endl;
printArray( array2 );
cout << "\nValues in array3 by row are:" << endl;
printArray( array3 );
} // end main
// output array with two rows and three columns
void printArray( const int a[][ columns ] )
{
int i , j ; // local variables
// loop through array's rows
for ( i = 0; i < rows; ++i )
{
// loop through columns of current row
for ( j = 0; j < columns; ++j )
cout << a[ i ][ j ] << ' ';
cout << endl; // start new line of output
} // end outer for
} // end function printArray